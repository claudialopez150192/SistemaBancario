package com.example.sistemaprestamos.controller;

import com.example.sistemaprestamos.domain.Usuario;
import com.example.sistemaprestamos.dto.UsuarioRequestDTO;
import com.example.sistemaprestamos.dto.UsuarioResponseDTO;
import com.example.sistemaprestamos.service.UsuarioService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    // Crear usuario
    @PostMapping
    public Mono<ResponseEntity<UsuarioResponseDTO>> crearUsuario(@Valid @RequestBody UsuarioRequestDTO dto) {
        Usuario usuario = new Usuario();
        usuario.setEmail(dto.getEmail());
        usuario.setPassword(dto.getPassword());
        usuario.setRol(dto.getRol());

        Usuario creado = usuarioService.crearUsuario(usuario);
        UsuarioResponseDTO response = new UsuarioResponseDTO(creado.getId(), creado.getEmail(), creado.getRol());
        return Mono.just(ResponseEntity.ok(response));
    }

    // Listar todos los usuarios
    @GetMapping
    public Flux<UsuarioResponseDTO> obtenerTodos() {
        List<UsuarioResponseDTO> usuarios = usuarioService.obtenerTodos().stream()
                .map(u -> new UsuarioResponseDTO(u.getId(), u.getEmail(), u.getRol()))
                .collect(Collectors.toList());
        return Flux.fromIterable(usuarios);
    }

    // Buscar por email
    @GetMapping("/email")
    public Mono<ResponseEntity<UsuarioResponseDTO>> buscarPorEmail(@RequestParam String email) {
        Usuario u = usuarioService.findByEmail(email);
        UsuarioResponseDTO response = new UsuarioResponseDTO(u.getId(), u.getEmail(), u.getRol());
        return Mono.just(ResponseEntity.ok(response));
    }

    // Actualizar usuario
    @PutMapping("/{id}")
    public Mono<ResponseEntity<UsuarioResponseDTO>> actualizarUsuario(@PathVariable Long id,
                                                                      @Valid @RequestBody UsuarioRequestDTO dto) {
        Usuario u = new Usuario();
        u.setId(id);
        u.setEmail(dto.getEmail());
        u.setRol(dto.getRol());
        Usuario actualizado = usuarioService.actualizarUsuario(u);
        UsuarioResponseDTO response = new UsuarioResponseDTO(actualizado.getId(), actualizado.getEmail(), actualizado.getRol());
        return Mono.just(ResponseEntity.ok(response));
    }

    // Eliminar usuario
    @DeleteMapping("/{id}")
    public Mono<ResponseEntity<Void>> eliminarUsuario(@PathVariable Long id) {
        usuarioService.eliminarUsuario(id);
        return Mono.just(ResponseEntity.noContent().build());
    }
}