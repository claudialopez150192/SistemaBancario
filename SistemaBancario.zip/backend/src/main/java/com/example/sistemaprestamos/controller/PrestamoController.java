package com.example.sistemaprestamos.controller;

import com.example.sistemaprestamos.domain.Prestamo;
import com.example.sistemaprestamos.domain.PrestamoStatus;
import com.example.sistemaprestamos.dto.PrestamoRequestDTO;
import com.example.sistemaprestamos.service.PrestamoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/prestamos")
public class PrestamoController {

    private final PrestamoService prestamoService;

    public PrestamoController(PrestamoService prestamoService) {
        this.prestamoService = prestamoService;
    }

    // Solicitar préstamo
    @PostMapping("/solicitar")
    public Mono<ResponseEntity<Prestamo>> solicitarPrestamo(@RequestParam Long usuarioId,
                                                            @Valid @RequestBody PrestamoRequestDTO dto) {
        return Mono.just(prestamoService.crearPrestamo(usuarioId, dto.getMonto(), dto.getPlazo()))
                   .map(ResponseEntity::ok);
    }

    // Aprobar préstamo (ADMIN)
    @PutMapping("/aprobar/{id}")
    public Mono<ResponseEntity<Prestamo>> aprobarPrestamo(@PathVariable Long id) {
        return Mono.just(prestamoService.cambiarEstado(id, PrestamoStatus.APROBADO))
                   .map(ResponseEntity::ok);
    }

    // Rechazar préstamo (ADMIN)
    @PutMapping("/rechazar/{id}")
    public Mono<ResponseEntity<Prestamo>> rechazarPrestamo(@PathVariable Long id) {
        return Mono.just(prestamoService.cambiarEstado(id, PrestamoStatus.RECHAZADO))
                   .map(ResponseEntity::ok);
    }

    // Consultar préstamos de un usuario
    @GetMapping("/usuario/{usuarioId}")
    public Flux<Prestamo> obtenerPrestamosPorUsuario(@PathVariable Long usuarioId) {
        List<Prestamo> prestamos = prestamoService.obtenerPrestamosPorUsuario(usuarioId);
        return Flux.fromIterable(prestamos);
    }

    // Consultar préstamo por ID
    @GetMapping("/{id}")
    public Mono<ResponseEntity<Prestamo>> obtenerPorId(@PathVariable Long id) {
        return Mono.just(prestamoService.obtenerPorId(id))
                   .map(ResponseEntity::ok);
    }
}