package com.example.sistemaprestamos.infrastructure.repository;

import com.example.sistemaprestamos.domain.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    // Buscar usuario por email
    Optional<Usuario> findByEmail(String email);

    // Verificar si ya existe un usuario con el email
    boolean existsByEmail(String email);
}