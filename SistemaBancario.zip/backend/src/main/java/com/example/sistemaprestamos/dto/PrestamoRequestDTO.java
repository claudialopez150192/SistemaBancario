package com.example.sistemaprestamos.dto;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class PrestamoRequestDTO {
    @NotNull @Min(1)
    private Double monto;
    @NotNull @Min(1)
    private Integer plazo;
}
