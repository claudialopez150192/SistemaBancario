package com.example.sistemaprestamos.service;

import com.example.sistemaprestamos.domain.Prestamo;
import com.example.sistemaprestamos.domain.PrestamoStatus;
import com.example.sistemaprestamos.domain.Usuario;
import com.example.sistemaprestamos.domain.exception.BusinessException;
import com.example.sistemaprestamos.domain.exception.NotFoundException;
import com.example.sistemaprestamos.infrastructure.repository.PrestamoRepository;
import com.example.sistemaprestamos.infrastructure.repository.UsuarioRepository;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PrestamoService {

    private final PrestamoRepository prestamoRepository;
    private final UsuarioRepository usuarioRepository;

    public PrestamoService(PrestamoRepository prestamoRepository, UsuarioRepository usuarioRepository) {
        this.prestamoRepository = prestamoRepository;
        this.usuarioRepository = usuarioRepository;
    }

    /**
     * Solicitar un préstamo
     */
    @Transactional
    public Prestamo crearPrestamo(Long usuarioId, Double monto, Integer plazo) {
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new NotFoundException("Usuario no encontrado"));

        // Validación: no puede tener préstamos pendientes
        List<Prestamo> pendientes = prestamoRepository.findByUsuario(usuario).stream()
                .filter(p -> p.getEstado() == PrestamoStatus.PENDIENTE)
                .toList();

        if (!pendientes.isEmpty()) {
            throw new BusinessException("El usuario ya tiene un préstamo pendiente");
        }

        Prestamo prestamo = new Prestamo();
        prestamo.setUsuario(usuario);
        prestamo.setMonto(monto);
        prestamo.setPlazo(plazo);
        prestamo.setEstado(PrestamoStatus.PENDIENTE);

        return prestamoRepository.save(prestamo);
    }

    /**
     * Aprobar o rechazar préstamo (transacción)
     */
    @Transactional
    public Prestamo cambiarEstado(Long prestamoId, PrestamoStatus estado) {
        Prestamo prestamo = prestamoRepository.findById(prestamoId)
                .orElseThrow(() -> new NotFoundException("Préstamo no encontrado"));
        prestamo.setEstado(estado);
        return prestamoRepository.save(prestamo);
    }

    /**
     * Consultar préstamos de un usuario con cache
     */
    @Cacheable("prestamosPorUsuario")
    public List<Prestamo> obtenerPrestamosPorUsuario(Long usuarioId) {
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new NotFoundException("Usuario no encontrado"));
        return prestamoRepository.findByUsuario(usuario);
    }

    /**
     * Obtener préstamo por ID
     */
    public Prestamo obtenerPorId(Long id) {
        return prestamoRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Préstamo no encontrado"));
    }
}