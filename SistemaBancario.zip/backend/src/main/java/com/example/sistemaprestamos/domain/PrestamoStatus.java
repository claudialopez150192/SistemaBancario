package com.example.sistemaprestamos.domain;

public enum PrestamoStatus {
    PENDIENTE,
    APROBADO,
    RECHAZADO
}
