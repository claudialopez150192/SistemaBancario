package com.example.sistemaprestamos.dto;
import com.example.sistemaprestamos.domain.PrestamoStatus;
import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class PrestamoResponseDTO {
    private Long id;
    private Double monto;
    private Integer plazo;
    private PrestamoStatus estado;
    private String usuarioId;
}
