
CREATE DATABASE IF NOT EXISTS prestamosdb;
USE prestamosdb;

CREATE TABLE IF NOT EXISTS usuarios (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    rol VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS prestamos (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    monto DOUBLE NOT NULL,
    plazo INT NOT NULL,
    estado VARCHAR(20) NOT NULL,
    usuario_id BIGINT,
    CONSTRAINT fk_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

INSERT IGNORE INTO usuarios (email, password, rol) VALUES
('usuario@test.com', '$2b$12$gXgMOaHJFfwJ8ovylc7Ex.Loq3YTvhk5rj07Wp.qGz9hSC3G2COTO', 'ROLE_USER'),
('admin@test.com', '$2b$12$Xn3RYItGmzRlyn2AImzSuuI6oZ9BT6vX8YxfMRP.PkW7xJpnxuU3i', 'ROLE_ADMIN');
