package com.example.sistemaprestamos.service;

import com.example.sistemaprestamos.domain.Prestamo;
import com.example.sistemaprestamos.domain.PrestamoStatus;
import com.example.sistemaprestamos.domain.Usuario;
import com.example.sistemaprestamos.infrastructure.repository.PrestamoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PrestamoServiceTest {

    private PrestamoRepository prestamoRepository;
    private PrestamoService prestamoService;

    @BeforeEach
    void setup() {
        prestamoRepository = mock(PrestamoRepository.class);
        prestamoService = new PrestamoService(prestamoRepository, null); // si usuarioRepository es requerido, mockearlo también
    }

    @Test
    void crearPrestamo_test() {
        Prestamo p = new Prestamo();
        p.setMonto(1000.0);
        p.setPlazo(12);
        p.setEstado(PrestamoStatus.PENDIENTE);

        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setEmail("usuario@test.com");
        p.setUsuario(usuario);

        when(prestamoRepository.save(any(Prestamo.class))).thenReturn(p);

        Prestamo creado = prestamoService.crearPrestamo(1L, 1000.0, 12);
        assertEquals(PrestamoStatus.PENDIENTE, creado.getEstado());
        verify(prestamoRepository, times(1)).save(any(Prestamo.class));
    }

    @Test
    void cambiarEstado_test() {
        Prestamo p = new Prestamo();
        p.setEstado(PrestamoStatus.PENDIENTE);

        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setEmail("usuario@test.com");
        p.setUsuario(usuario);

        when(prestamoRepository.findById(anyLong())).thenReturn(Optional.of(p));
        when(prestamoRepository.save(any(Prestamo.class))).thenReturn(p);

        Prestamo actualizado = prestamoService.cambiarEstado(1L, PrestamoStatus.APROBADO);
        assertEquals(PrestamoStatus.APROBADO, actualizado.getEstado());
    }
}