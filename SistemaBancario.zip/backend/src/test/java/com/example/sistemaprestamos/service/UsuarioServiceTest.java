package com.example.sistemaprestamos.service;

import com.example.sistemaprestamos.domain.Usuario;
import com.example.sistemaprestamos.infrastructure.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Optional;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class UsuarioServiceTest {

    private UsuarioRepository usuarioRepository;
    private UsuarioService usuarioService;

    @BeforeEach
    void setup() {
        usuarioRepository = mock(UsuarioRepository.class);
        usuarioService = new UsuarioService(usuarioRepository);
    }

    @Test
    void findByEmail_test() {
        Usuario u = new Usuario();
        u.setEmail("usuario@test.com");
        when(usuarioRepository.findByEmail("usuario@test.com")).thenReturn(Optional.of(u));

        Usuario encontrado = usuarioService.findByEmail("usuario@test.com");
        assertEquals("usuario@test.com", encontrado.getEmail());
    }
}
